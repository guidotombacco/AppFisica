export const KEYS = {
  uiOpen: "ui.open",
  goal: "plan.goal",
  xp: "plan.xp",
  focus: "plan.focus",
  equip: "plan.equip",
  upper1: "plan.upper1",
  lower1: "plan.lower1",
  upper2: "plan.upper2",
  lower2: "plan.lower2",
} as const;
